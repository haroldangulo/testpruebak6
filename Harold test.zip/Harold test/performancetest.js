import http from 'k6/http';
import { check, group } from 'k6';
import { SharedArray } from 'k6/data';
import { htmlReport } from 'https://raw.githubusercontent.com/benc-uk/k6-reporter/main/dist/bundle.js';

// Cargar datos del CSV
const data = new SharedArray('users', function () {
  return open('./users.csv').split('\n').slice(1).filter(line => line.trim()).map(line => {
    const [user, passwd] = line.split(',');
    return { user: user.trim(), passwd: passwd.trim() };
  }).filter(item => item.user && item.passwd);
});

export const options = {
  scenarios: {
    stress: {
      executor: 'ramping-arrival-rate',
      startRate: 5,
      timeUnit: '1s',
      preAllocatedVUs: 50,
      maxVUs: 100,
      stages: [
        { duration: '2m', target: 20 },
        { duration: '5m', target: 20 },
        { duration: '2m', target: 0 },
      ],
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<1500', 'p(99)<2000'],
    http_req_failed: ['rate<0.03'],
  },
};

export default function () {
  const cred = data[Math.floor(Math.random() * data.length)];

  group('Login Test', () => {
    const res = http.post('https://fakestoreapi.com/auth/login', JSON.stringify({
      username: cred.user,
      password: cred.passwd,
    }), {
      headers: { 'Content-Type': 'application/json' },
      timeout: '60s',
    });

    check(res, {
      'status is 200': (r) => r.status === 200,
      'response time < 1500ms': (r) => r.timings.duration < 1500,
      'response is not empty': (r) => r.body && r.body.length > 0,
    });
  });
}

// Generar reporte HTML automáticamente
export function handleSummary(data) {
  return {
    'results.html': htmlReport(data),
    stdout: textSummary(data, { indent: ' ', enableColors: true }),
  };
}

function textSummary(data, options) {
  let summary = '\n\n===== K6 TEST SUMMARY =====\n';
  summary += `Execution Time: ${new Date().toLocaleString()}\n\n`;
  
  // Métricas HTTP
  if (data.metrics.http_reqs) {
    summary += `HTTP Requests: ${Math.round(data.metrics.http_reqs.values.count)}\n`;
    summary += `Request Duration (avg): ${Math.round(data.metrics.http_req_duration.values.avg)}ms\n`;
    summary += `Request Duration (p95): ${Math.round(data.metrics.http_req_duration.values['p(95)'])}ms\n`;
    summary += `Request Duration (p99): ${Math.round(data.metrics.http_req_duration.values['p(99)'])}ms\n`;
    summary += `Failed Requests: ${Math.round(data.metrics.http_req_failed.values.rate * 100)}%\n`;
  }
  
  // Iteraciones
  if (data.metrics.iterations) {
    summary += `\nIterations: ${Math.round(data.metrics.iterations.values.count)}\n`;
  }
  
  // Checks
  if (data.metrics.checks) {
    summary += `\nChecks: ${Math.round(data.metrics.checks.values.passes)} passed, `;
    summary += `${Math.round(data.metrics.checks.values.failures)} failed\n`;
  }
  
  // Data
  if (data.metrics.data_received) {
    summary += `\nData Received: ${(data.metrics.data_received.values.value / 1024 / 1024).toFixed(2)} MB\n`;
  }
  if (data.metrics.data_sent) {
    summary += `Data Sent: ${(data.metrics.data_sent.values.value / 1024 / 1024).toFixed(2)} MB\n`;
  }
  
  summary += '\n✅ HTML report generated: results.html\n';
  summary += '=============================\n\n';
  
  return summary;
}